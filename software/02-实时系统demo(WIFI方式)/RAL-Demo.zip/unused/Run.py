from PyQt5 import QtWidgets
import Win
import torch
import torch.nn.functional as F
import threading
#!python3
# Keysight VISA COM Example in Python using "comtypes"
# *********************************************************
# This program illustrates a few commonly used programming
# features of your Keysight oscilloscope.
# *********************************************************
# Import Python modules.
# ---------------------------------------------------------
import sys
import numpy as np
from comtypes.client import GetModule
from comtypes.client import CreateObject
import time
# Run GetModule once to generate comtypes.gen.VisaComLib.
if not hasattr(sys, "frozen"):
    GetModule("C:\Program Files (x86)\IVI Foundation\VISA\VisaCom\GlobMgr.dll")

import comtypes.gen.VisaComLib as VisaComLib



# Initialize the oscilloscope, capture data, and analyze.
def do_query_number(query):
    myScope.WriteString("%s" % query, True)
    result = myScope.ReadNumber(VisaComLib.ASCIIType_R8, True)
    check_instrument_errors(query)
    return result
def do_query_ieee_block(query):
    myScope.WriteString("%s" % query, True)
    result = myScope.ReadIEEEBlock(VisaComLib.BinaryType_UI1, \
    False, True)
    check_instrument_errors(query)
    return result
def check_instrument_errors(command):
    while True:
        myScope.WriteString(":SYSTem:ERRor?", True)
        error_string = myScope.ReadString()
        if error_string: # If there is an error string value.
            if error_string.find("+0,", 0, 3) == -1: # Not "No error".
                print("ERROR: %s, command: '%s'" % (error_string, command))
                print("Exited because of error.")
                sys.exit(1)
            else: # "No error"
                break
        else: # :SYSTem:ERRor? should always return string.
            print("ERROR: :SYSTem:ERRor? returned nothing, command: '%s'" \
            % command)
            print("Exited because of error.")
            sys.exit(1)
def do_command(command) -> object:
    myScope.WriteString("%s" % command, True)
    check_instrument_errors(command)
def do_query_numbers(query):
    myScope.WriteString("%s" % query, True)
    result = myScope.ReadList(VisaComLib.ASCIIType_R8, ",;")
    check_instrument_errors(query)
    return result
# =========================================================
# Send a query, check for errors, return string:
# =========================================================
def do_query_string(query):
    myScope.WriteString("%s" % query, True)
    result = myScope.ReadString()
    check_instrument_errors(query)
    return result
# =========================================================
# Main program:
# =========================================================
rm = CreateObject("VISA.GlobalRM", interface=VisaComLib.IResourceManager)
myScope = CreateObject("VISA.BasicFormattedIO", interface=VisaComLib.IFormattedIO488)
myScope.IO = rm.Open("TCPIP0::169.254.45.43::INSTR")
# Clear the interface.
myScope.IO.Clear()
print("Interface cleared.")
# Set the Timeout to 15 seconds.
myScope.IO.Timeout = 15000  # 15 seconds.
print("Timeout set to 15000 milliseconds.")
class RUN(Win.Win):
    def __init__(self, parent=None):
        super(RUN, self).__init__(parent)
        self.show_img("Air", self.lbgas)
        self.show_img("0.002", self.lbpressure)
        self.th0 = threading.Thread(target=self.update0)
        self.Loadnet2()
        self.CONNECT()
        self.pressurelist = ['0.002','0.006','0.011','0.021','0.031','0.041','0.051','0.061','0.071','0.081','0.091','0.101']
        # self.gaslist = ['Air', 'Ar', 'CO2', 'He', 'N2']
        self.gaslist = ['Air', 'Ar']

    def triger(self, flag):
        self.th0.start()
        pass

    def CONNECT(self):
        self.pbStart.clicked.connect(self.triger)

    def predict2(self, li):
        print((li@li.T)/1999)
        if (li@li.T)/1999 < 0.05:
            self.show_img("white", self.lbpressure)
            self.show_img("white", self.lbgas)
            return None

        li = li.reshape((1,1,1999))
        li=li[:,:,0:1998]
        #
        # li=li[:,:,0:600]
        li = li.astype(np.float32)
        # maxv = np.max(li)
        maxv = 18.9285
        # maxv = 12.815
        li = li/maxv
        temp = li
        for i in range(16):
            temp = np.concatenate((temp,li), axis=0)
        inp = torch.from_numpy(temp)
        output_gas = self.CNN1D_gas(inp)
        print("GAS", output_gas)
        print("GAS", inp)
        output_pressure = self.CNN1D_pressure(torch.from_numpy(temp))

        ans_gas = F.log_softmax(output_gas, dim=1).argmax(dim=1).detach().numpy()
        ans_pressure = F.log_softmax(output_pressure, dim=1).argmax(dim=1).detach().numpy()

        self.show_img(self.gaslist[ans_gas[0]], self.lbgas)
        self.show_img(self.pressurelist[ans_pressure[0]], self.lbpressure)
        return None

    def predict(self, li):
        print((li@li.T)/1999)
        if (li@li.T)/1999 < 0.05:
            self.show_img("white", self.lbpressure)
            self.show_img("white", self.lbgas)
        li = li.reshape((1,1,1999))
        li=li[:,:,0:1998]
        # li=li[:,:,0:600]
        li = li.astype(np.float32)
        # maxv = np.max(li)
        maxv = 18.9285
        # maxv = 12.815
        li = li/maxv
        temp = li
        for i in range(16):
            temp = np.concatenate((temp,li), axis=0)
        output = self.CNN1D(torch.from_numpy(temp))
        ans = F.log_softmax(output, dim=1).argmax(dim=1).detach().numpy()[0]
        pressure = int(ans % 12)
        gas = int(ans/12)
        print(ans, gas, pressure)
        self.show_img(self.gaslist[gas], self.lbgas)
        self.show_img(self.pressurelist[pressure], self.lbpressure)
        return

    def Loadnet(self):
        self.CNN1D = torch.load("./res/models/390FJJ24-2.pth", map_location=torch.device('cpu'))
        print(self.CNN1D)

    def Loadnet2(self):
        self.CNN1D_gas = torch.load("./res/models/190FJJ24-2-gas.pth", map_location=torch.device('cpu'))
        self.CNN1D_pressure = torch.load("./res/models/190FJJ24-2-gas.pth", map_location=torch.device('cpu'))

    def update0(self):
        ( wav_form, acq_type, wfmpts, avgcnt,
         x_increment,x_origin,x_reference,
         y_increment,y_origin,y_reference) = do_query_numbers(":WAVeform:PREamble?")
        print("Waveform points desired: %d" % wfmpts)
        print("Waveform average count: %d" % avgcnt)
        print("Waveform X increment: %1.12f" % x_increment)
        print("Waveform X origin: %1.9f" % x_origin)
        print("Waveform X reference: %d" % x_reference)  # Always 0.
        print("Waveform Y increment: %f" % y_increment)
        print("Waveform Y origin: %f" % y_origin)
        print("Waveform Y reference: %d" % y_reference)  # Always 125.
        # Get numeric values for later calculations.
        x_increment = do_query_number(":WAVeform:XINCrement?")
        x_origin = do_query_number(":WAVeform:XORigin?")
        y_increment = do_query_number(":WAVeform:YINCrement?")
        y_origin = do_query_number(":WAVeform:YORigin?")
        y_reference = do_query_number(":WAVeform:YREFerence?")
        # Get the waveform data.
        # Get the number of waveform points available.
        do_command(":WAVeform:POINts 2000")
        qresult = do_query_string(":WAVeform:POINts?")
        print("Waveform points available: %s" % qresult)
        self.Alldata = np.array(range(2000))
        while 1:
            do_command(":SINGle")
            time.sleep(2.35)
            data_bytes = do_query_ieee_block(":WAVeform:DATA?")
            nLength = len(data_bytes)
            voltage=[]
            for i in range(0, nLength):
                # time_val = x_origin + (i * x_increment)
                voltage.append((data_bytes[i] - y_reference) * y_increment + y_origin)

        # frame = 0
        # D = scio.loadmat("./res/mat/Scope24.mat")
        # DataXY = D["SCOPE"]
        # while 1:
        #     frame = frame + 1
        #     X = DataXY[frame,0:2000]
        #     Y = DataXY[frame,1999]
        #     print("LABEL: ",Y)
        #     time.sleep(2.35)
        #     voltage=X.tolist()


            # print(type(data_bytes), nLength)
            # print(np.array(data_bytes, dtype=np.float))
            print("Number of data values: %d" % len(voltage))
            pX = np.arange(0,len(voltage))
            pY = np.array(voltage, dtype=np.float)
            # self.Alldata = np.concatenate((self.Alldata, pY), axis=0)
            self.PWPlot1Ploter.setData(pX,pY)


            takendata = pY[1:2000]
            ans = self.predict2(takendata)
            # self.decodeClass(ans[0])

            ffty = np.fft.fft(pY)
            fr = np.array(range(0,len(pY)))/1
            region = (int)(len(fr)/2)
            fX = fr[1:region]
            fY = abs(ffty)[1:region]
            self.PWPlot2Ploter.setData(fX, fY)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    # app.setAttribute(QtCore.Qt.AA_Use96Dpi)
    mainWindow = RUN()
    mainWindow.show()
    sys.exit(app.exec_())
