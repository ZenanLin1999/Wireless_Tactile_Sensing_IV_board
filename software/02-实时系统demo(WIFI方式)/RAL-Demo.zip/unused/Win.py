from PyQt5 import QtWidgets,QtGui
import sys
from ParentUI import ZiLabCUHK
import pyqtgraph as pg

class Win(ZiLabCUHK.Ui_MainWindow, QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(Win, self).__init__(parent)
        self.setupUi(self)
        # 画布1
        pg.setConfigOptions(leftButtonPan=True)
        pg.setConfigOption('background', 'w')
        pg.setConfigOption('foreground', 'k')

        self.PWPlot1 = pg.PlotWidget(self.centralwidget)
        self.PWPlot2 = pg.PlotWidget(self.centralwidget)
        self.PWPlot1Ploter = self.PWPlot1.plot(name='DataStream', pen=pg.mkPen(width=3, color='b'))
        self.PWPlot2Ploter = self.PWPlot2.plot(name='DataStream', pen=pg.mkPen(width=3, color='b'))
        self.PWList = [self.PWPlot1, self.PWPlot2]
        self.VLYPlot = [QtWidgets.QVBoxLayout(self.lbrealtime), QtWidgets.QVBoxLayout(self.lbfft)]

        for i in range(self.PWList.__len__()):
            self.VLYPlot[i].addWidget(self.PWList[i])
            # self.PWPlot1.setGeometry(QtCore.QRect(0, 0, 400, 400))
            self.PWList[i].addLegend()
            self.PWList[i].setAntialiasing(False)
            # self.PWList[i].setLabel('left', 'G')
            # self.PWList[i].setLabel('bottom', 'Time')

    def show_img(self, name, pos):
        img = QtGui.QPixmap("./res/pictures/"+name+".png")#.scaled(pos.size().width(), pos.size().height())
        print(pos.size().width())
        print(pos.size().height())
        pos.setPixmap(img)
        # pos.setScaledContents(False)  # 图片自适应LABEL大小

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    # app.setAttribute(QtCore.Qt.AA_Use96Dpi)
    mainWindow = Win()
    mainWindow.show()
    sys.exit(app.exec_())