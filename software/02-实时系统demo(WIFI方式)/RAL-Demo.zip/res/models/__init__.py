# -*- coding: utf-8 -*-
'''
@time: 2019/9/8 20:13

@ author: javis
'''

from resnet import resnet18, resnet34, resnet50, resnet101, resnet152